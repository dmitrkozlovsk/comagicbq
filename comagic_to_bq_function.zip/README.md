# comagicbq
Автоматический импорт отчета о звонках из CoMagic в BigQuery 
