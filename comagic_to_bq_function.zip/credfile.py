google_credintials_key_path = '' #Путь к credentials для проекта, если запуск с десктопа
full_table_id = '' #Полное название таиблцы BQ для записи данных о звонках

COMAGIC_PASSWORD = '' #Паролль для доступа в CoMagic
COMAGIC_LOGIN = '' #Логин для доступа в CoMagic
FIRST_CALL_DATE = '' # Дата, с которой необходимо начинать загрузку отчета о звонках. 'YYYY-MM-DD'
